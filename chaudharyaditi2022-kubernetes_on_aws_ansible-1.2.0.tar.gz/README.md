# Ansible Collection - chaudharyaditi2022.kubernetes_on_aws_ansible

Documentation for the collection.

# kubernetes-on-aws-ansible-roles
Launches Kubernetes cluster on aws using ansible roles


This project launches Kubernetes cluster on AWS Cloud with `3 nodes (one master node and two worker nodes)`. It launches three EC2 instances, configures docker and
configures kubernetes master and slave node in the launched instances.


## Prerequisites

Before you begin, ensure you have met the following requirements:

* Make sure your system has following softwares and libraries installed.

To install awscli use following commands:
```
$sudo apt update
$sudo apt install python3-pip
$pip3 install awscli
```
or
```
$sudo yum update
$sudo yum install python3-pip
$pip3 install awscli
```

Once the CLI is installed, run aws configure and enter your AWS access key ID and secret access key.
```
aws configure
cat .aws/credentials
```
You can get keys from the Your Security Credentials page in the AWS Management Console. Here's how those keys will look
```
AccessKeyId: AKIALNZTQW6H3EFBRLHQ
SecretAccessKey: f26B8touguUBELGpdyCyc9o0ZDzP2MEUWNC0JNwA
```

To install Ansible use following command
```
$pip install ansible
$ansible --version

$pip3 install boto boto3
```

## Usage

Follow these steps:
* Download the collection using following command. Default location where collection is installed is `/root/.ansible/collections/ansible_collections/`
```
$ansible-galaxy collection install chaudharyaditi2022.kubernetes_on_aws_ansible

$cd /root/.ansible/collections/ansible_collections/chaudharyaditi2022/
```
### Roles Description
* aws_ec2 :- Launches three ec2 instances on aws
* docker_configure :- Installs and configures docker 
* kubernetes_configure_master :- Configures kubernetes master node
* kubernetes_configure_worker :- Configures kubernetes worker node

### Files description 
Location: `/kubernetes_on_aws_ansible/docs/`
* inventory_aws_ec2.yml :- Inventory file which dynamically fetches infomation about launched instances .
* main.yml :- playbook which runs roles to setup Kubernetes.

To launch instances follow the following steps
* Configure ansible.cfg file by adding following under `[defaults]` block following lines-
```
private_key_file=  /root/.ansible/collections/ansible_collections/chaudharyaditi2022/kubernetes_on_aws_ansible/docs/Kubernetes-cluster-key.pem
remote_user= ec2-user
```

* Run the following commands to launch kubernetes cluster
```
 ansible-playbook -i  /root/.ansible/collections/ansible_collections/chaudharyaditi2022/kubernetes_on_aws_ansible/docs/inventory_aws_ec2.yml 
        /root/.ansible/collections/ansible_collections/chaudharyaditi2022/kubernetes_on_aws_ansible/docs/main.yml

```





